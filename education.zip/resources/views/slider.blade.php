<!-- Sidebar -->
<ul class="navbar-nav bg-primary sidebar sidebar-dark accordion toggled" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="/">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">SERU<sup>M</sup></div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <li class="nav-item active">
        <a class="nav-link" href="/">
            <i class="fas fa-user-alt"></i>
            {{--                <span>Dashboard</span>--}}
        </a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="/">
            <i class="fas fa-building"></i>
            {{--                <span>Charts</span>--}}
        </a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="tables/">
            <i class="fas fa-clipboard"></i>
            {{--                <span>Tables</span>--}}
        </a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="tables/">
            <i class="fas fa-shield-alt"></i>
            {{--                <span>Tables</span>--}}
        </a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="tables/">
            <i class="fas fa-plus-square"></i>
            {{--                <span>Tables</span>--}}
        </a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="tables/">
            <i class="fas fa-address-card"></i>
            {{--                <span>Tables</span>--}}
        </a>
    </li>
    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul>
<!-- End of Sidebar -->
